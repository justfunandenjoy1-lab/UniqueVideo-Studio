# Keep Media3 Transformer & Effects classes
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
