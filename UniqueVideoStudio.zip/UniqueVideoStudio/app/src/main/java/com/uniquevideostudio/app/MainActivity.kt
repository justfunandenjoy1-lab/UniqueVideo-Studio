package com.uniquevideostudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.uniquevideostudio.app.ui.StudioScreen
import com.uniquevideostudio.app.ui.StudioViewModel
import com.uniquevideostudio.app.ui.theme.UniqueVideoStudioTheme

class MainActivity : ComponentActivity() {

    private val studioViewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UniqueVideoStudioTheme {
                StudioScreen(viewModel = studioViewModel)
            }
        }
    }
}
