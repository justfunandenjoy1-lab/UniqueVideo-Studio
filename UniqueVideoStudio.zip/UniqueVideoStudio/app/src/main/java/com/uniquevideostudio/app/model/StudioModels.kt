package com.uniquevideostudio.app.model

import android.net.Uri
import java.util.UUID

enum class AspectPreset(val label: String, val width: Int, val height: Int) {
    ORIGINAL("Original", 0, 0),
    VERTICAL_9_16("9:16 Reels/Shorts", 1080, 1920),
    SQUARE_1_1("1:1 Square", 1080, 1080),
    LANDSCAPE_16_9("16:9 YouTube", 1920, 1080)
}

enum class BannerMode(val label: String) {
    NONE("No Banner"),
    TOP_BOTTOM("Top & Bottom Bar"),
    LEFT_RIGHT_SIDE("Side Banners (L/R)"),
    L_BAR_FRAME("L-Bar Frame")
}

enum class LogoPosition(val label: String, val ndcX: Float, val ndcY: Float) {
    TOP_LEFT("Top Left", -0.82f, 0.82f),
    TOP_CENTER("Top Center", 0.0f, 0.82f),
    TOP_RIGHT("Top Right", 0.82f, 0.82f),
    CENTER_LEFT("Center Left", -0.82f, 0.0f),
    CENTER("Center", 0.0f, 0.0f),
    CENTER_RIGHT("Center Right", 0.82f, 0.0f),
    BOTTOM_LEFT("Bottom Left", -0.82f, -0.82f),
    BOTTOM_CENTER("Bottom Center", 0.0f, -0.82f),
    BOTTOM_RIGHT("Bottom Right", 0.82f, -0.82f)
}

enum class VideoCodecOption(val label: String, val mimeType: String) {
    H264_AVC("H.264 (AVC) — Universal", "video/avc"),
    H265_HEVC("H.265 (HEVC) — High Efficiency", "video/hevc")
}

data class ExportConfig(
    val codec: VideoCodecOption = VideoCodecOption.H264_AVC,
    val bitrateMbps: Float = 8.0f,
    val aspectPreset: AspectPreset = AspectPreset.ORIGINAL,
    val bannerMode: BannerMode = BannerMode.NONE,
    val bannerColorHex: String = "#1D4ED8",
    val bannerThicknessPercent: Float = 12f,
    val bannerImageUriString: String? = null,
    val logoUriString: String? = null,
    val logoPosition: LogoPosition = LogoPosition.TOP_RIGHT,
    val logoOpacity: Float = 0.85f,
    val logoScale: Float = 0.22f,
    val dynamicCornerShift: Boolean = false,
    val shiftIntervalSec: Int = 15,
    val lowerThirdText: String = "",
    val lowerThirdBgHex: String = "#0F172A",
    val muteAudio: Boolean = false,
    val forceUniqueReencode: Boolean = true
)

data class BrandKitPreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val config: ExportConfig
)

data class VideoMetadataReport(
    val displayName: String,
    val sha256: String,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val bitrateBps: Long
) {
    val shortHash: String
        get() = if (sha256.length >= 16) "${sha256.take(8)}...${sha256.takeLast(8)}" else sha256
}

enum class BatchStatus {
    PENDING,
    INSPECTING,
    ENCODING,
    SAVING,
    COMPLETED,
    FAILED
}

data class BatchVideoItem(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: Uri,
    val displayName: String,
    val status: BatchStatus = BatchStatus.PENDING,
    val progressPercent: Int = 0,
    val beforeReport: VideoMetadataReport? = null,
    val afterReport: VideoMetadataReport? = null,
    val savedGalleryPath: String? = null,
    val errorMessage: String? = null
)
