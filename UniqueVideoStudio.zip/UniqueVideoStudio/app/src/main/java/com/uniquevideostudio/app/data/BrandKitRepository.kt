package com.uniquevideostudio.app.data

import android.content.Context
import com.uniquevideostudio.app.model.AspectPreset
import com.uniquevideostudio.app.model.BannerMode
import com.uniquevideostudio.app.model.BrandKitPreset
import com.uniquevideostudio.app.model.ExportConfig
import com.uniquevideostudio.app.model.LogoPosition
import com.uniquevideostudio.app.model.VideoCodecOption
import org.json.JSONArray
import org.json.JSONObject

class BrandKitRepository(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadPresets(): List<BrandKitPreset> {
        val raw = prefs.getString(KEY_PRESETS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val cfg = obj.getJSONObject("config")
                    add(
                        BrandKitPreset(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            config = ExportConfig(
                                codec = enumValueOrDefault(cfg.optString("codec"), VideoCodecOption.H264_AVC),
                                bitrateMbps = cfg.optDouble("bitrateMbps", 8.0).toFloat(),
                                aspectPreset = enumValueOrDefault(cfg.optString("aspectPreset"), AspectPreset.ORIGINAL),
                                bannerMode = enumValueOrDefault(cfg.optString("bannerMode"), BannerMode.NONE),
                                bannerColorHex = cfg.optString("bannerColorHex", "#1D4ED8"),
                                bannerThicknessPercent = cfg.optDouble("bannerThicknessPercent", 12.0).toFloat(),
                                bannerImageUriString = cfg.optString("bannerImageUriString").ifBlank { null },
                                logoUriString = cfg.optString("logoUriString").ifBlank { null },
                                logoPosition = enumValueOrDefault(cfg.optString("logoPosition"), LogoPosition.TOP_RIGHT),
                                logoOpacity = cfg.optDouble("logoOpacity", 0.85).toFloat(),
                                logoScale = cfg.optDouble("logoScale", 0.22).toFloat(),
                                dynamicCornerShift = cfg.optBoolean("dynamicCornerShift", false),
                                shiftIntervalSec = cfg.optInt("shiftIntervalSec", 15),
                                lowerThirdText = cfg.optString("lowerThirdText", ""),
                                lowerThirdBgHex = cfg.optString("lowerThirdBgHex", "#0F172A"),
                                muteAudio = cfg.optBoolean("muteAudio", false),
                                forceUniqueReencode = cfg.optBoolean("forceUniqueReencode", true)
                            )
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun savePreset(preset: BrandKitPreset): List<BrandKitPreset> {
        val current = loadPresets().filterNot { it.id == preset.id } + preset
        persist(current)
        return current
    }

    fun deletePreset(id: String): List<BrandKitPreset> {
        val updated = loadPresets().filterNot { it.id == id }
        persist(updated)
        return updated
    }

    private fun persist(presets: List<BrandKitPreset>) {
        val arr = JSONArray()
        presets.forEach { preset ->
            val c = preset.config
            val cfgObj = JSONObject().apply {
                put("codec", c.codec.name)
                put("bitrateMbps", c.bitrateMbps.toDouble())
                put("aspectPreset", c.aspectPreset.name)
                put("bannerMode", c.bannerMode.name)
                put("bannerColorHex", c.bannerColorHex)
                put("bannerThicknessPercent", c.bannerThicknessPercent.toDouble())
                put("bannerImageUriString", c.bannerImageUriString ?: "")
                put("logoUriString", c.logoUriString ?: "")
                put("logoPosition", c.logoPosition.name)
                put("logoOpacity", c.logoOpacity.toDouble())
                put("logoScale", c.logoScale.toDouble())
                put("dynamicCornerShift", c.dynamicCornerShift)
                put("shiftIntervalSec", c.shiftIntervalSec)
                put("lowerThirdText", c.lowerThirdText)
                put("lowerThirdBgHex", c.lowerThirdBgHex)
                put("muteAudio", c.muteAudio)
                put("forceUniqueReencode", c.forceUniqueReencode)
            }
            val itemObj = JSONObject().apply {
                put("id", preset.id)
                put("name", preset.name)
                put("config", cfgObj)
            }
            arr.put(itemObj)
        }
        prefs.edit().putString(KEY_PRESETS, arr.toString()).apply()
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(name: String, default: T): T {
        return runCatching { enumValueOf<T>(name) }.getOrDefault(default)
    }

    companion object {
        private const val PREFS_NAME = "unique_video_studio_prefs"
        private const val KEY_PRESETS = "brand_kit_presets_v1"
    }
}
