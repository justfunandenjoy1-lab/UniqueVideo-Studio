package com.uniquevideostudio.app.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.uniquevideostudio.app.data.BrandKitRepository
import com.uniquevideostudio.app.engine.GallerySaver
import com.uniquevideostudio.app.engine.UniqueVideoEngine
import com.uniquevideostudio.app.engine.VideoInspector
import com.uniquevideostudio.app.model.BatchStatus
import com.uniquevideostudio.app.model.BatchVideoItem
import com.uniquevideostudio.app.model.BrandKitPreset
import com.uniquevideostudio.app.model.ExportConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class StudioUiState(
    val config: ExportConfig = ExportConfig(),
    val queue: List<BatchVideoItem> = emptyList(),
    val presets: List<BrandKitPreset> = emptyList(),
    val isProcessing: Boolean = false,
    val statusBanner: String? = null
)

@OptIn(UnstableApi::class)
class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val presetRepo = BrandKitRepository(appContext)
    private val engine = UniqueVideoEngine(appContext)

    private val _uiState = MutableStateFlow(
        StudioUiState(presets = presetRepo.loadPresets())
    )
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var batchJob: Job? = null

    fun updateConfig(transform: (ExportConfig) -> ExportConfig) {
        _uiState.update { it.copy(config = transform(it.config)) }
    }

    fun setLogoUri(uri: Uri?) {
        uri?.let { takePersistableReadPermission(it) }
        updateConfig { it.copy(logoUriString = uri?.toString()) }
    }

    fun setBannerImageUri(uri: Uri?) {
        uri?.let { takePersistableReadPermission(it) }
        updateConfig { it.copy(bannerImageUriString = uri?.toString()) }
    }

    fun addVideos(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val newItems = uris.map { uri ->
                takePersistableReadPermission(uri)
                val name = VideoInspector.getDisplayName(appContext, uri)
                BatchVideoItem(sourceUri = uri, displayName = name)
            }
            _uiState.update { state ->
                state.copy(
                    queue = state.queue + newItems,
                    statusBanner = "${newItems.size} video(s) added to queue."
                )
            }
        }
    }

    fun removeVideo(id: String) {
        if (_uiState.value.isProcessing) return
        _uiState.update { state ->
            state.copy(queue = state.queue.filterNot { it.id == id })
        }
    }

    fun clearQueue() {
        if (_uiState.value.isProcessing) return
        _uiState.update { it.copy(queue = emptyList(), statusBanner = null) }
    }

    fun saveBrandKit(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val updated = presetRepo.savePreset(
            BrandKitPreset(name = trimmed, config = _uiState.value.config)
        )
        _uiState.update {
            it.copy(presets = updated, statusBanner = "Brand Kit '$trimmed' saved offline.")
        }
    }

    fun applyBrandKit(preset: BrandKitPreset) {
        _uiState.update {
            it.copy(config = preset.config, statusBanner = "Applied Brand Kit '${preset.name}'.")
        }
    }

    fun deleteBrandKit(id: String) {
        val updated = presetRepo.deletePreset(id)
        _uiState.update { it.copy(presets = updated) }
    }

    fun startBatchExport() {
        val state = _uiState.value
        if (state.isProcessing || state.queue.isEmpty()) return

        batchJob = viewModelScope.launch {
            _uiState.update {
                it.copy(isProcessing = true, statusBanner = "Batch unique re-encoding started...")
            }

            val configSnapshot = _uiState.value.config
            val itemsToRun = _uiState.value.queue.filter {
                it.status == BatchStatus.PENDING || it.status == BatchStatus.FAILED
            }

            var successCount = 0
            for (item in itemsToRun) {
                try {
                    updateItem(item.id) {
                        it.copy(status = BatchStatus.INSPECTING, progressPercent = 0, errorMessage = null)
                    }

                    val beforeReport = withContext(Dispatchers.IO) {
                        VideoInspector.inspectUri(appContext, item.sourceUri, item.displayName)
                    }

                    updateItem(item.id) {
                        it.copy(status = BatchStatus.ENCODING, beforeReport = beforeReport, progressPercent = 2)
                    }

                    val encodedFile = engine.transcodeVideo(
                        sourceUri = item.sourceUri,
                        sourceWidth = beforeReport.width,
                        sourceHeight = beforeReport.height,
                        config = configSnapshot,
                        onProgress = { pct ->
                            updateItem(item.id) { it.copy(progressPercent = pct) }
                        }
                    )

                    updateItem(item.id) {
                        it.copy(status = BatchStatus.SAVING, progressPercent = 99)
                    }

                    val (afterReport, savedPath) = withContext(Dispatchers.IO) {
                        val after = VideoInspector.inspectFile(encodedFile)
                        val baseName = item.displayName.substringBeforeLast('.')
                        val outName = "${baseName}_unique_${System.currentTimeMillis() % 100000}.mp4"
                        val path = GallerySaver.saveVideoToGallery(appContext, encodedFile, outName)
                        encodedFile.delete()
                        after to path
                    }

                    updateItem(item.id) {
                        it.copy(
                            status = BatchStatus.COMPLETED,
                            progressPercent = 100,
                            afterReport = afterReport,
                            savedGalleryPath = savedPath
                        )
                    }
                    successCount++
                } catch (ce: CancellationException) {
                    updateItem(item.id) {
                        it.copy(status = BatchStatus.PENDING, progressPercent = 0)
                    }
                    throw ce
                } catch (e: Exception) {
                    updateItem(item.id) {
                        it.copy(
                            status = BatchStatus.FAILED,
                            errorMessage = e.localizedMessage ?: "Encoding failed"
                        )
                    }
                }
            }

            _uiState.update {
                it.copy(
                    isProcessing = false,
                    statusBanner = "Finished! $successCount/${itemsToRun.size} video(s) exported to Movies/UniqueVideoStudio."
                )
            }
        }
    }

    fun cancelExport() {
        batchJob?.cancel()
        batchJob = null
        _uiState.update {
            it.copy(isProcessing = false, statusBanner = "Export cancelled.")
        }
    }

    private fun updateItem(id: String, transform: (BatchVideoItem) -> BatchVideoItem) {
        _uiState.update { state ->
            state.copy(queue = state.queue.map { if (it.id == id) transform(it) else it })
        }
    }

    private fun takePersistableReadPermission(uri: Uri) {
        runCatching {
            appContext.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }
}
