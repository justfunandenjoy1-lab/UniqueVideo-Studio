package com.uniquevideostudio.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.uniquevideostudio.app.model.AspectPreset
import com.uniquevideostudio.app.model.ExportConfig
import com.uniquevideostudio.app.model.LogoPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@UnstableApi
class UniqueVideoEngine(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())

    suspend fun transcodeVideo(
        sourceUri: Uri,
        sourceWidth: Int,
        sourceHeight: Int,
        config: ExportConfig,
        onProgress: (Int) -> Unit
    ): File {
        val (targetW, targetH) = resolveTargetDimensions(sourceWidth, sourceHeight, config.aspectPreset)

        // Prepare overlay bitmaps off the Main thread
        val (bannerBitmap, logoBitmap) = withContext(Dispatchers.IO) {
            val banner = OverlayBitmapGenerator.buildBannerAndLowerThirdBitmap(
                context = context,
                canvasWidth = targetW,
                canvasHeight = targetH,
                config = config
            )
            val logo = OverlayBitmapGenerator.loadScaledBitmap(
                context = context,
                uriString = config.logoUriString,
                maxDimension = 512
            )
            banner to logo
        }

        val tempDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val uniqueId = UUID.randomUUID().toString().take(8)
        val outputFile = File(tempDir, "UVS_${System.currentTimeMillis()}_$uniqueId.mp4")
        if (outputFile.exists()) outputFile.delete()

        return try {
            runTransformerOnMain(
                sourceUri = sourceUri,
                outputFile = outputFile,
                config = config,
                bannerBitmap = bannerBitmap,
                logoBitmap = logoBitmap,
                onProgress = onProgress
            )
        } finally {
            bannerBitmap?.recycle()
            logoBitmap?.recycle()
        }
    }

    private suspend fun runTransformerOnMain(
        sourceUri: Uri,
        outputFile: File,
        config: ExportConfig,
        bannerBitmap: Bitmap?,
        logoBitmap: Bitmap?,
        onProgress: (Int) -> Unit
    ): File = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { cont ->
            val videoEffects = mutableListOf<Effect>()

            // 1. Target Aspect Ratio / Resolution
            if (config.aspectPreset != AspectPreset.ORIGINAL) {
                videoEffects.add(
                    Presentation.createForWidthAndHeight(
                        config.aspectPreset.width,
                        config.aspectPreset.height,
                        Presentation.LAYOUT_SCALE_TO_FIT
                    )
                )
            }

            // 2. Identity GL Effect guarantees full hardware decode -> fresh re-encode
            //    so bitstream & SHA-256 hash are 100% unique with zero visual alteration.
            if (config.forceUniqueReencode) {
                videoEffects.add(RgbAdjustment.Builder().build())
            }

            // 3. Banner, Lower-Third & Custom Logo Overlays
            val overlays = mutableListOf<TextureOverlay>()
            if (bannerBitmap != null) {
                overlays.add(BitmapOverlay.createStaticBitmapOverlay(bannerBitmap))
            }
            if (logoBitmap != null) {
                overlays.add(createLogoOverlay(logoBitmap, config))
            }
            if (overlays.isNotEmpty()) {
                videoEffects.add(OverlayEffect(ImmutableList.copyOf(overlays)))
            }

            val mediaItem = MediaItem.fromUri(sourceUri)
            val editedMediaItem = EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(emptyList(), videoEffects))
                .setRemoveAudio(config.muteAudio)
                .build()

            val targetBitrateBps = (config.bitrateMbps.coerceIn(2f, 30f) * 1_000_000f).toInt()
            val encoderFactory = DefaultEncoderFactory.Builder(context)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder()
                        .setBitrate(targetBitrateBps)
                        .build()
                )
                .build()

            val progressHolder = ProgressHolder()
            var pollRunnable: Runnable? = null

            val transformer = Transformer.Builder(context)
                .setVideoMimeType(config.codec.mimeType)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        pollRunnable?.let { mainHandler.removeCallbacks(it) }
                        onProgress(100)
                        if (cont.isActive) cont.resume(outputFile)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        pollRunnable?.let { mainHandler.removeCallbacks(it) }
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                })
                .build()

            pollRunnable = object : Runnable {
                override fun run() {
                    val state = transformer.getProgress(progressHolder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgress(progressHolder.progress.coerceIn(0, 99))
                    }
                    if (cont.isActive) {
                        mainHandler.postDelayed(this, 200L)
                    }
                }
            }

            cont.invokeOnCancellation {
                pollRunnable?.let { mainHandler.removeCallbacks(it) }
                mainHandler.post { runCatching { transformer.cancel() } }
            }

            transformer.start(editedMediaItem, outputFile.absolutePath)
            mainHandler.postDelayed(pollRunnable, 200L)
        }
    }

    private fun createLogoOverlay(logoBitmap: Bitmap, config: ExportConfig): BitmapOverlay {
        val corners = listOf(
            LogoPosition.TOP_RIGHT,
            LogoPosition.BOTTOM_RIGHT,
            LogoPosition.BOTTOM_LEFT,
            LogoPosition.TOP_LEFT
        )
        val scale = config.logoScale.coerceIn(0.08f, 0.55f)
        val alpha = config.logoOpacity.coerceIn(0.1f, 1.0f)
        val intervalUs = (config.shiftIntervalSec.coerceIn(5, 120)) * 1_000_000L

        return object : BitmapOverlay() {
            override fun getBitmap(presentationTimeUs: Long): Bitmap = logoBitmap

            override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
                val pos = if (config.dynamicCornerShift) {
                    val idx = ((presentationTimeUs / intervalUs) % corners.size).toInt().coerceAtLeast(0)
                    corners[idx]
                } else {
                    config.logoPosition
                }
                return OverlaySettings.Builder()
                    .setAlphaScale(alpha)
                    .setScale(scale, scale)
                    .setBackgroundFrameAnchor(pos.ndcX, pos.ndcY)
                    .setOverlayFrameAnchor(pos.ndcX, pos.ndcY)
                    .build()
            }
        }
    }

    private fun resolveTargetDimensions(
        sourceW: Int,
        sourceH: Int,
        preset: AspectPreset
    ): Pair<Int, Int> {
        if (preset != AspectPreset.ORIGINAL) return preset.width to preset.height
        val w = if (sourceW > 0) sourceW else 1080
        val h = if (sourceH > 0) sourceH else 1920
        return w to h
    }
}
