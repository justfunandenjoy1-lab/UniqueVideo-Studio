package com.uniquevideostudio.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import com.uniquevideostudio.app.model.BannerMode
import com.uniquevideostudio.app.model.ExportConfig
import kotlin.math.max
import kotlin.math.min

object OverlayBitmapGenerator {

    fun loadScaledBitmap(context: Context, uriString: String?, maxDimension: Int = 1024): Bitmap? {
        if (uriString.isNullOrBlank()) return null
        val uri = runCatching { Uri.parse(uriString) }.getOrNull() ?: return null

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, boundsOpts)
        }
        if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return null

        var sampleSize = 1
        while (boundsOpts.outWidth / sampleSize > maxDimension || boundsOpts.outHeight / sampleSize > maxDimension) {
            sampleSize *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        }
    }

    /**
     * Generates a full-frame transparent overlay bitmap containing custom Side Banners,
     * Top/Bottom Banners, L-Bar Frame, and Bengali/English Lower-Third text strip.
     */
    fun buildBannerAndLowerThirdBitmap(
        context: Context,
        canvasWidth: Int,
        canvasHeight: Int,
        config: ExportConfig
    ): Bitmap? {
        val hasBanner = config.bannerMode != BannerMode.NONE
        val hasLowerThird = config.lowerThirdText.isNotBlank()
        if (!hasBanner && !hasLowerThird) return null

        val w = max(360, min(canvasWidth, 1920))
        val h = max(360, min(canvasHeight, 1920))
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bannerColor = parseHexColor(config.bannerColorHex, Color.parseColor("#1D4ED8"))
        val bannerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bannerColor
            style = Paint.Style.FILL
        }
        val accentLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(180, 255, 255, 255)
            style = Paint.Style.FILL
        }
        val bannerImage = loadScaledBitmap(context, config.bannerImageUriString, maxDimension = 1280)

        val ratio = (config.bannerThicknessPercent.coerceIn(5f, 28f)) / 100f

        when (config.bannerMode) {
            BannerMode.NONE -> Unit
            BannerMode.TOP_BOTTOM -> {
                val barH = (h * ratio).toInt()
                drawBannerRect(canvas, Rect(0, 0, w, barH), bannerPaint, bannerImage)
                drawBannerRect(canvas, Rect(0, h - barH, w, h), bannerPaint, bannerImage)
                canvas.drawRect(0f, barH.toFloat() - 3f, w.toFloat(), barH.toFloat(), accentLinePaint)
                canvas.drawRect(0f, (h - barH).toFloat(), w.toFloat(), (h - barH + 3).toFloat(), accentLinePaint)
            }
            BannerMode.LEFT_RIGHT_SIDE -> {
                val barW = (w * ratio).toInt()
                drawBannerRect(canvas, Rect(0, 0, barW, h), bannerPaint, bannerImage)
                drawBannerRect(canvas, Rect(w - barW, 0, w, h), bannerPaint, bannerImage)
                canvas.drawRect(barW.toFloat() - 3f, 0f, barW.toFloat(), h.toFloat(), accentLinePaint)
                canvas.drawRect((w - barW).toFloat(), 0f, (w - barW + 3).toFloat(), h.toFloat(), accentLinePaint)
            }
            BannerMode.L_BAR_FRAME -> {
                val sideW = (w * ratio).toInt()
                val bottomH = (h * (ratio * 0.9f)).toInt()
                drawBannerRect(canvas, Rect(0, 0, sideW, h), bannerPaint, bannerImage)
                drawBannerRect(canvas, Rect(0, h - bottomH, w, h), bannerPaint, bannerImage)
                canvas.drawRect(sideW.toFloat() - 3f, 0f, sideW.toFloat(), (h - bottomH).toFloat(), accentLinePaint)
                canvas.drawRect(sideW.toFloat(), (h - bottomH).toFloat(), w.toFloat(), (h - bottomH + 3).toFloat(), accentLinePaint)
            }
        }

        if (hasLowerThird) {
            drawLowerThirdStrip(canvas, w, h, config.lowerThirdText.trim(), config.lowerThirdBgHex)
        }

        bannerImage?.recycle()
        return bitmap
    }

    private fun drawBannerRect(canvas: Canvas, target: Rect, fallbackPaint: Paint, image: Bitmap?) {
        if (image != null) {
            canvas.drawBitmap(image, null, target, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            canvas.drawRect(target, fallbackPaint)
        }
    }

    private fun drawLowerThirdStrip(
        canvas: Canvas,
        w: Int,
        h: Int,
        text: String,
        bgHex: String
    ) {
        val bgColor = parseHexColor(bgHex, Color.parseColor("#0F172A"))
        val barHeight = max(56f, h * 0.068f)
        val marginX = w * 0.04f
        val bottomMargin = h * 0.045f
        val top = h - bottomMargin - barHeight
        val rect = RectF(marginX, top, w - marginX, top + barHeight)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(225, Color.red(bgColor), Color.green(bgColor), Color.blue(bgColor))
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(rect, 14f, 14f, bgPaint)

        val accentBar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(marginX, top, marginX + 10f, top + barHeight), 6f, 6f, accentBar)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (barHeight * 0.44f).coerceIn(24f, 48f)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(4f, 0f, 2f, Color.argb(160, 0, 0, 0))
        }

        val fm = textPaint.fontMetrics
        val baseline = rect.centerY() - (fm.ascent + fm.descent) / 2f
        val maxTextWidth = rect.width() - 48f
        val fittedText = ellipsizeToWidth(text, textPaint, maxTextWidth)
        canvas.drawText(fittedText, marginX + 26f, baseline, textPaint)
    }

    private fun ellipsizeToWidth(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var end = text.length
        while (end > 1 && paint.measureText(text.substring(0, end) + "…") > maxWidth) {
            end--
        }
        return text.substring(0, end) + "…"
    }

    private fun parseHexColor(hex: String, fallback: Int): Int {
        return runCatching { Color.parseColor(hex.trim()) }.getOrDefault(fallback)
    }
}
