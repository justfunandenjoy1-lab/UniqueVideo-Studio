package com.uniquevideostudio.app.engine

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object GallerySaver {

    fun saveVideoToGallery(context: Context, sourceFile: File, outputFileName: String): String {
        val safeName = if (outputFileName.endsWith(".mp4", ignoreCase = true)) {
            outputFileName
        } else {
            "$outputFileName.mp4"
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, safeName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/UniqueVideoStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = resolver.insert(collection, values)
                ?: throw IllegalStateException("Failed to create MediaStore entry for $safeName")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
            } ?: throw IllegalStateException("Failed to open output stream for $safeName")

            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)

            "Movies/UniqueVideoStudio/$safeName"
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "UniqueVideoStudio"
            )
            if (!moviesDir.exists()) moviesDir.mkdirs()
            val dest = File(moviesDir, safeName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(dest).use { out ->
                    input.copyTo(out)
                }
            }
            dest.absolutePath
        }
    }
}
