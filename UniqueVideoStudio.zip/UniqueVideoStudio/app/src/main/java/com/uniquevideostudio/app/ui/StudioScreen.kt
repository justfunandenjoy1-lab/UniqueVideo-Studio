package com.uniquevideostudio.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uniquevideostudio.app.model.AspectPreset
import com.uniquevideostudio.app.model.BannerMode
import com.uniquevideostudio.app.model.BatchStatus
import com.uniquevideostudio.app.model.BatchVideoItem
import com.uniquevideostudio.app.model.LogoPosition
import com.uniquevideostudio.app.model.VideoCodecOption
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(viewModel: StudioViewModel) {
    val state by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        viewModel.addVideos(uris)
    }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        viewModel.setLogoUri(uri)
    }

    val bannerImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        viewModel.setBannerImageUri(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "UniqueVideo Studio",
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp
                        )
                        Text(
                            text = "100% Offline • Unique Re-Encoder & Branding",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "Queue") },
                    label = { Text("Videos") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Brush, contentDescription = "Branding") },
                    label = { Text("Branding") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Encoding") },
                    label = { Text("Encoding") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = "Brand Kits") },
                    label = { Text("Kits") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            state.statusBanner?.let { msg ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = msg,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            when (selectedTab) {
                0 -> QueueTab(
                    state = state,
                    onPickVideos = { videoPicker.launch(arrayOf("video/*")) },
                    onStart = { viewModel.startBatchExport() },
                    onCancel = { viewModel.cancelExport() },
                    onRemove = { viewModel.removeVideo(it) },
                    onClear = { viewModel.clearQueue() }
                )
                1 -> BrandingTab(
                    state = state,
                    viewModel = viewModel,
                    onPickLogo = { logoPicker.launch(arrayOf("image/*")) },
                    onPickBannerImage = { bannerImagePicker.launch(arrayOf("image/*")) }
                )
                2 -> EncodingTab(state = state, viewModel = viewModel)
                3 -> BrandKitsTab(state = state, viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun QueueTab(
    state: StudioUiState,
    onPickVideos: () -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onRemove: (String) -> Unit,
    onClear: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onPickVideos,
                enabled = !state.isProcessing,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Add Videos")
            }

            if (state.isProcessing) {
                Button(
                    onClick = onCancel,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Cancel")
                }
            } else {
                Button(
                    onClick = onStart,
                    enabled = state.queue.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Encode (${state.queue.size})")
                }
            }
        }

        if (state.queue.isNotEmpty() && !state.isProcessing) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "Clear Queue",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { onClear() }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        if (state.queue.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "No videos in queue",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Tap 'Add Videos' to select 1 or multiple clips for unique re-encoding & branding.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.queue, key = { it.id }) { item ->
                    BatchItemCard(
                        item = item,
                        canDelete = !state.isProcessing,
                        onRemove = { onRemove(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun BatchItemCard(
    item: BatchVideoItem,
    canDelete: Boolean,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.displayName,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = when (item.status) {
                            BatchStatus.PENDING -> "Ready to encode"
                            BatchStatus.INSPECTING -> "Inspecting SHA-256 & metadata..."
                            BatchStatus.ENCODING -> "Hardware re-encoding... ${item.progressPercent}%"
                            BatchStatus.SAVING -> "Verifying new hash & saving to Gallery..."
                            BatchStatus.COMPLETED -> "Completed • 100% Unique Hash Verified"
                            BatchStatus.FAILED -> "Failed: ${item.errorMessage ?: "Unknown error"}"
                        },
                        fontSize = 12.5.sp,
                        color = when (item.status) {
                            BatchStatus.COMPLETED -> MaterialTheme.colorScheme.secondary
                            BatchStatus.FAILED -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                when (item.status) {
                    BatchStatus.COMPLETED -> Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Done",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    BatchStatus.FAILED -> Icon(
                        Icons.Default.Error,
                        contentDescription = "Error",
                        tint = MaterialTheme.colorScheme.error
                    )
                    else -> if (canDelete) {
                        IconButton(onClick = onRemove) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove")
                        }
                    }
                }
            }

            if (item.status == BatchStatus.ENCODING || item.status == BatchStatus.SAVING) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { item.progressPercent / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (item.beforeReport != null && item.afterReport != null) {
                Spacer(Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                val isUnique = item.beforeReport.sha256 != item.afterReport.sha256
                Text(
                    text = if (isUnique) "SHA-256 VERIFIED: 100% UNIQUE CODE" else "SHA-256 CHECK",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Before: ${item.beforeReport.shortHash} (${item.beforeReport.width}x${item.beforeReport.height})",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "After:  ${item.afterReport.shortHash} (${item.afterReport.width}x${item.afterReport.height})",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                item.savedGalleryPath?.let { path ->
                    Text(
                        text = "Saved: $path",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BrandingTab(
    state: StudioUiState,
    viewModel: StudioViewModel,
    onPickLogo: () -> Unit,
    onPickBannerImage: () -> Unit
) {
    val cfg = state.config
    val colorSwatches = listOf("#1D4ED8", "#0F766E", "#0F172A", "#B91C1C", "#7C3AED", "#D97706")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Custom Logo Watermark", fontWeight = FontWeight.Bold, fontSize = 16.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onPickLogo) {
                Text(if (cfg.logoUriString == null) "Select Logo (PNG/JPG)" else "Change Logo")
            }
            if (cfg.logoUriString != null) {
                OutlinedButton(onClick = { viewModel.setLogoUri(null) }) {
                    Text("Remove")
                }
            }
        }

        Text("Logo Position (9-Point Anchor)", fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LogoPosition.entries.forEach { pos ->
                FilterChip(
                    selected = cfg.logoPosition == pos && !cfg.dynamicCornerShift,
                    onClick = { viewModel.updateConfig { it.copy(logoPosition = pos, dynamicCornerShift = false) } },
                    label = { Text(pos.label, fontSize = 12.sp) }
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Dynamic Corner Shift", fontWeight = FontWeight.Medium)
                Text(
                    "Auto-move logo between 4 corners every ${cfg.shiftIntervalSec}s",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = cfg.dynamicCornerShift,
                onCheckedChange = { checked -> viewModel.updateConfig { it.copy(dynamicCornerShift = checked) } }
            )
        }

        if (cfg.dynamicCornerShift) {
            Slider(
                value = cfg.shiftIntervalSec.toFloat(),
                onValueChange = { v -> viewModel.updateConfig { it.copy(shiftIntervalSec = v.roundToInt()) } },
                valueRange = 5f..60f
            )
        }

        Text("Logo Opacity: ${(cfg.logoOpacity * 100).roundToInt()}%", fontSize = 13.sp)
        Slider(
            value = cfg.logoOpacity,
            onValueChange = { v -> viewModel.updateConfig { it.copy(logoOpacity = v) } },
            valueRange = 0.15f..1.0f
        )

        Text("Logo Size Scale: ${(cfg.logoScale * 100).roundToInt()}%", fontSize = 13.sp)
        Slider(
            value = cfg.logoScale,
            onValueChange = { v -> viewModel.updateConfig { it.copy(logoScale = v) } },
            valueRange = 0.10f..0.45f
        )

        HorizontalDivider()

        Text("Side Banners & L-Bar Frame", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BannerMode.entries.forEach { mode ->
                FilterChip(
                    selected = cfg.bannerMode == mode,
                    onClick = { viewModel.updateConfig { it.copy(bannerMode = mode) } },
                    label = { Text(mode.label, fontSize = 12.5.sp) }
                )
            }
        }

        if (cfg.bannerMode != BannerMode.NONE) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onPickBannerImage) {
                    Text(if (cfg.bannerImageUriString == null) "Custom Banner Image" else "Change Banner Image")
                }
                if (cfg.bannerImageUriString != null) {
                    OutlinedButton(onClick = { viewModel.setBannerImageUri(null) }) {
                        Text("Use Color")
                    }
                }
            }

            Text("Banner Color", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                colorSwatches.forEach { hex ->
                    val parsed = Color(android.graphics.Color.parseColor(hex))
                    val selected = cfg.bannerColorHex.equals(hex, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(parsed)
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.onBackground else Color.Gray,
                                shape = CircleShape
                            )
                            .clickable { viewModel.updateConfig { it.copy(bannerColorHex = hex) } }
                    )
                }
            }

            Text("Banner Thickness: ${cfg.bannerThicknessPercent.roundToInt()}%", fontSize = 13.sp)
            Slider(
                value = cfg.bannerThicknessPercent,
                onValueChange = { v -> viewModel.updateConfig { it.copy(bannerThicknessPercent = v) } },
                valueRange = 6f..25f
            )
        }

        HorizontalDivider()

        Text("Lower-Third Text / Ticker (Bangla & English)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        OutlinedTextField(
            value = cfg.lowerThirdText,
            onValueChange = { txt -> viewModel.updateConfig { it.copy(lowerThirdText = txt) } },
            label = { Text("Channel Name / Breaking Ticker / Handle") },
            placeholder = { Text("e.g. Subscribe @YourChannel • নতুন ভিডিও") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EncodingTab(
    state: StudioUiState,
    viewModel: StudioViewModel
) {
    val cfg = state.config

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Unique Re-Encoding Engine", fontWeight = FontWeight.Bold, fontSize = 16.sp)

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Force Unique Bitstream & Hash", fontWeight = FontWeight.Medium)
                Text(
                    "Full hardware decode + fresh re-encode with stripped metadata while preserving visual quality",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = cfg.forceUniqueReencode,
                onCheckedChange = { v -> viewModel.updateConfig { it.copy(forceUniqueReencode = v) } }
            )
        }

        Text("Output Video Codec", fontWeight = FontWeight.Medium, fontSize = 14.sp)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            VideoCodecOption.entries.forEach { codec ->
                FilterChip(
                    selected = cfg.codec == codec,
                    onClick = { viewModel.updateConfig { it.copy(codec = codec) } },
                    label = { Text(codec.label) }
                )
            }
        }

        Text("Target Aspect Ratio Preset", fontWeight = FontWeight.Medium, fontSize = 14.sp)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AspectPreset.entries.forEach { preset ->
                FilterChip(
                    selected = cfg.aspectPreset == preset,
                    onClick = { viewModel.updateConfig { it.copy(aspectPreset = preset) } },
                    label = { Text(preset.label, fontSize = 12.5.sp) }
                )
            }
        }

        Text("Target Video Bitrate: ${cfg.bitrateMbps.roundToInt()} Mbps (Higher = Sharper)", fontSize = 13.5.sp)
        Slider(
            value = cfg.bitrateMbps,
            onValueChange = { v -> viewModel.updateConfig { it.copy(bitrateMbps = v) } },
            valueRange = 4f..24f
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Mute Output Audio", fontWeight = FontWeight.Medium)
                Text(
                    "Remove original audio track during re-encoding",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = cfg.muteAudio,
                onCheckedChange = { v -> viewModel.updateConfig { it.copy(muteAudio = v) } }
            )
        }
    }
}

@Composable
private fun BrandKitsTab(
    state: StudioUiState,
    viewModel: StudioViewModel
) {
    var kitName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Save Current Settings as Brand Kit", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = kitName,
                onValueChange = { kitName = it },
                label = { Text("Channel / Preset Name") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Button(
                onClick = {
                    viewModel.saveBrandKit(kitName)
                    kitName = ""
                },
                enabled = kitName.isNotBlank()
            ) {
                Text("Save")
            }
        }

        HorizontalDivider()

        Text("Saved Brand Kits (${state.presets.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)

        if (state.presets.isEmpty()) {
            Text(
                text = "No saved Brand Kits yet. Configure your logo, side banner, and encoding settings, then save a kit here for 1-tap reuse.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.presets, key = { it.id }) { preset ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(preset.name, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${preset.config.aspectPreset.label} • ${preset.config.bannerMode.label} • ${preset.config.bitrateMbps.roundToInt()} Mbps",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            OutlinedButton(onClick = { viewModel.applyBrandKit(preset) }) {
                                Text("Apply")
                            }
                            IconButton(onClick = { viewModel.deleteBrandKit(preset.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Preset")
                            }
                        }
                    }
                }
            }
        }
    }
}
